clc; clear; close all;
load dataNE
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Y = a;
n = 800;
T=length(Y);
step = 1;
l = 5;
tr=T-n-step-l+1;
for j=1:T-l-step+1
    input(j,:)=Y(j:j+l-1);
    output(j,:)=Y(j+l:j+l+step-1)';
end
output=output(:,step);
input_train=input(1:tr,:)';
input_test=input(tr+1:end,:)';
output_train=output(1:tr)';
output_test=a(end-n+1:end);
%% 训练数据和预测数据归一化
[inputn,inputps]=mapminmax(input_train,0,1);
[outputn,outputps]=mapminmax(output_train,0,1);
inputn_test=mapminmax('apply',input_test,inputps);
%% 分位数预测
% QRLSTM
tau = 0.05
[PRE_LSTM]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau);
hold on
plot(PRE_LSTM,'r-')
plot(output_test,'b')
hold off
PICP = sum(PRE_LSTM'<output_test)/length(output_test)*100
quantileloss = QR(output_test, PRE_LSTM', tau)  % 计算quantile loss

%% 区间预测
tau1 = [0.05, 0.95];
for i = 1:2
[PRE_LSTM(i,:)]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
end
hold on
plot(PRE_LSTM','r-')
plot(output_test,'b')
hold off
% 评价
alpha = 1-(tau1(2)-tau(1));
UB = PRE_LSTM(2,:)';
LB = PRE_LSTM(1,:)';
actual = output_test;
[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)
%% 预测0.0001到0.9999. 间隔0.005
tau1 = 0.001:0.005:0.999;
for i = 1:length(tau1)
    PRE_LSTM(i,:)=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
end

%% KDE
load result.mat
%设置核函数分别为Gaussian，Uniform，Triangle和Epanechnikov
%调用ksdensity函数进行核密度检验
%[f_ks1,xi1]=ksdensity(score,'kernel','normal');
%[f_ks2,xi2]=ksdensity(score,'kernel','box');
%[f_ks3,xi3]=ksdensity(score,'kernel','triangle');
%[f_ks4,xi4]=ksdensity(score,'kernel','epanechnikov');
% 绘制几个时刻上的概率密度
for i = 1:4
    data = PRE_LSTM(:,i);
    [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    subplot(2,2,i)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('电力负荷')
    ylabel('条件概率密度')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([output_test(i,:),output_test(i,:)],ylim,'r--','linewidth',1); % 绘制x=1的直线
end


