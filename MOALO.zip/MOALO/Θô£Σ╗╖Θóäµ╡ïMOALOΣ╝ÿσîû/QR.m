function [loss] = QR(act, pre, tau)
loss = mean(max(tau*(act-pre),(1-tau)*(pre-act)));
end