clear;
clc;
%%  导入数据
load common_train.mat
P_train = common_train(:,1:4)';  %commom_train的第1-20行存放到P_train中 P变量，T铜
T_train = common_train(:,end)';   %取最后一列  

load common_test.mat
P_test = common_test(:,1:4)';
T_test = common_test(:,end)';

P_validation = common_train(216:288,1:4)';  %common_train的第216-288行存放到P_validation中 
T_validation = common_train(216:288,end)';

f_=size(P_train, 1);                  % 输入特征维度
outdim = 1;    
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);

%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[p_validation, ps_P_validation] = mapminmax(P_validation, 0, 1);
[t_validation, ps_T_validation] = mapminmax(T_validation, 0, 1);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);


%预测测试值
tau = 0.975
[PRE_QR_test_975]=QRLSTM(p_train, t_train,ps_output,p_test,t_test,tau);
PICP_test = sum(PRE_QR_test_975>T_test)/length(T_test)*100
quantileloss = QR(T_test, PRE_QR_test_975, tau)