# -*- coding: utf-8 -*-
"""
Created on Fri Nov 25 19:38:46 2022

@author: 帅
"""

from __future__ import print_function
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import torch
from torch.autograd import Variable
from split_ws import split_ws
from sklearn.model_selection import train_test_split
from sklearn import preprocessing
from keras import backend as K
plt.style.use('seaborn')
num_feature = 5
tau=0.05
class My_loss(nn.Module):
      def __init__(self):
              super().__init__()
        
      def forward(self, x, y, tau): #  x为实际值，y为输出值.quantile loss
              return torch.sum(torch.max(tau*(x-y), (tau-1)*(x-y)))

class Sequence(nn.Module):
    def __init__(self):
        super(Sequence, self).__init__()
        self.lstm1 = nn.LSTMCell(1, 50, 5)   
        self.lstm2 = nn.LSTMCell(50, 50, 5)  
        self.linear = nn.Linear(50, 1)  
        self.drop = nn.Dropout(0)
        
    def forward(self, input):
        outputs = []
        h_t = torch.zeros(input.shape[0], 50, dtype=torch.double) 
        c_t = torch.zeros(input.shape[0], 50, dtype=torch.double)  # 第一个数是所有样本数量，可以用batch
        h_t2 = torch.zeros(input.shape[0], 50, dtype=torch.double)
        c_t2 = torch.zeros(input.shape[0], 50, dtype=torch.double)

        for i, input_t in enumerate(input.chunk(input.shape[0], dim=1)):
            h_t, c_t = self.lstm1(input_t, (h_t, c_t))
            h_t2, c_t2 = self.lstm2(h_t, (h_t2, c_t2))
            output = self.linear(self.drop(h_t2))
            outputs += [output]
        outputs = torch.stack(outputs, 1).squeeze(2)
        return outputs
    
if __name__ == '__main__':
    # set random seed to 0
    data = pd.read_csv('./Ct.csv')  # 可选gold,al,zn。 copper效果不好
    newdata = data.iloc[:,[1]]
    X_train, X_test, y_train, y_test = split_ws(newdata, train_size=0.85, lag=1, num_feature=num_feature)
    y_train = pd.DataFrame(y_train)
    _, X_valid, _, y_valid = train_test_split(X_train, y_train, 
                                                 train_size=0.8, shuffle = False, stratify=None)  

    # （2）归一化/标准化处理
    scaler = preprocessing.StandardScaler().fit(X_train)
    X_train_n=scaler.transform(X_train)

    scaler1 = preprocessing.StandardScaler().fit(y_train)
    y_train_n=scaler1.transform(y_train)
    
    X_valid_n = scaler.transform(X_valid)
    y_valid_n = scaler1.transform(y_valid)
   
   # X_train_n=X_train_n.reshape(X_train_n.shape[0],1,X_train_n.shape[1])
   # X_valid_n=X_valid_n.reshape(X_valid_n.shape[0],1,X_valid_n.shape[1])

#将ndarray数据转换为pytorch可用的数据类型——张量
    X_train_n = torch.from_numpy(X_train_n)
    y_train_n = torch.from_numpy(y_train_n)
    X_test_n = scaler.transform(X_test)
    dataX1 = X_test_n
    valid_input = torch.from_numpy(X_valid_n)     #  验证集上的输入
    prediction_input = torch.from_numpy(dataX1)   #  测试集上的输入
    seq = Sequence()
    seq.double()

    # criterion = nn.MSELoss()
    # use LBFGS as optimizer since we can load the whole data to train
    optimizer = optim.Adam(seq.parameters(), lr=0.01)

    y = []
    #begin to train
    for i in range(200):            # 控制迭代次数
        print('STEP: ', i)
        def closure():
            optimizer.zero_grad()
            out = seq(X_train_n)[:,-2:-1]
            criterion=My_loss()      
            loss = criterion(y_train_n, out, tau) 
            print('loss:', loss.item())
            loss.backward()
            return loss
        optimizer.step(closure)
        # begin to predict, no need to track gradient here
        
    with torch.no_grad():
         pred = seq(prediction_input)
         y = pred.detach().numpy()
         predict = scaler1.inverse_transform(y)
         predict = predict[:,-2:-1]
         

    _, _, _, y_test = split_ws(pd.read_csv('./Ct.csv').iloc[:,[1]], 
                               train_size=0.85, lag=1, num_feature=5)

     
    pltx=np.arange(1,len(predict)+1)
    fig=plt.figure(num=1,figsize=(15,5),dpi=600)
    plt.plot(pltx,y_test,'o-', linewidth=1, markersize=3,label='Observation values')
    plt.plot(pltx,predict,'*-', linewidth=1,markersize=1.5, label='LSTM')
    plt.legend(['Observation values','LSTM'])
    plt.show()

       # 计算误差指标
    num1 = len(predict>y_test)
    picp = num1/y_test.shape[0] *100
    print("Testdatasets picp:",picp)