function [PRE]=QRLSTM(pn,tn,outputps,pn1,y,tau);
% pn代表inputn  tn代表outputn pn1是inputn_test,y是真实值。

numResponses = 1;
featureDimension = size(pn,1);
numHiddenUnits = 5;

layers = [ ...
    sequenceInputLayer(featureDimension)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numHiddenUnits)
    dropoutLayer(0.25)             
    fullyConnectedLayer(numResponses)
    quanRegressionLayer('out',tau)];

options = trainingOptions('adam', ...
    'MaxEpochs',100, ...
    'MiniBatchSize',32, ...
    'InitialLearnRate',0.01, ...
    'ExecutionEnvironment','gpu',...
    'GradientThreshold',1, ...
    'Shuffle','every-epoch', ...
    'Verbose',0);

net = trainNetwork(pn,tn,layers,options);
YPred = predict(net,pn1,'MiniBatchSize',1);
PRE= mapminmax('reverse',YPred,outputps);
end