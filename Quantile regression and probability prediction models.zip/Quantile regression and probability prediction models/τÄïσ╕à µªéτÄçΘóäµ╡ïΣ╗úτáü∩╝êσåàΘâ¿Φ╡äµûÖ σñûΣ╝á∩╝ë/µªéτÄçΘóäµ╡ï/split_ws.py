# -*- coding: utf-8 -*-
"""
Created on Sun Nov 21 14:32:03 2021

@author: 帅
"""
import numpy as np
from sklearn.model_selection import train_test_split

def split_ws(data, train_size, lag, num_feature): # train_size 是 训练集比例，lag是预测步数，num_feature是延迟步数
    while np.shape(data)[1] <= np.shape(data)[0]:
        data = data.T
    X1 = list()
    for i in range(np.shape(data)[1] - (num_feature + lag -1)):    #  
        X1.append(data.iloc[0,i:i+num_feature+lag])
    X1 = np.squeeze(X1)
    X = X1[:,0:num_feature]
    y = X1[:,num_feature+lag-1]             # 生成的X和y就是1步预测的监督学习数据
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=train_size, shuffle = False, stratify=None)
    return X_train, X_test, y_train, y_test


