load kernel_QRLSTM.mat
%设置核函数分别为Gaussian，Uniform，Triangle和Epanechnikov
%调用ksdensity函数进行核密度检验
% [f_ks1,xi1]=ksdensity(score,'kernel','normal');
% [f_ks2,xi2]=ksdensity(score,'kernel','box');
% [f_ks3,xi3]=ksdensity(score,'kernel','triangle');
%f_ks4,xi4]=ksdensity(kernel_QRLSTM,'kernel','epanechnikov');
%绘制几个时刻上的概率密度
n = linspace(1, 73, 9)
for i = 1:9
    data = kernel_QRLSTM(:,n(i));
    [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
    subplot(3,3,i)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('copper price')
    ylabel('条件概率密度')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,n(i)),T_test(:,n(i))],ylim,'r--','linewidth',1); % 绘制x=1的直线
end