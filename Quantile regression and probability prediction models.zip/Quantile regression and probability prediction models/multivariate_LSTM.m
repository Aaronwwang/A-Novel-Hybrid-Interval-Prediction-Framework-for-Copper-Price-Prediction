clear;clc;
%%  导入数据
%金价
n=0.8;%训练集占比
load golddata2.mat
gold_price=golddata2;
train=gold_price(1:880*n,:);
test=gold_price(880*n+1:879,:);

P_train = train(:,2:end)';  %xtrain的第1-20列存放到P_train中 P变量，T铜
T_train = train(:,1)';   
P_test = test(:,2:end)';
T_test = test(:,1)';                  % 输入特征维度
outdim = 1;                           % 最后一列为输出
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);
%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%% 区间预测

gold_LSTM=LSTM(p_train, t_train,ps_output,p_test,T_test);

%quantileloss = QR(T_test, gold_LSTM(i,:), tau1(i))

%画图
hold on
plot(gold_LSTM','r-')
plot(T_test,'b')
hold off
%评价指标
%alpha = 1-(tau1(2)-tau1(1));
%UB = gold_LSTM(2,:);
%LB = gold_LSTM(1,:);
%actual = T_test;
%[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)