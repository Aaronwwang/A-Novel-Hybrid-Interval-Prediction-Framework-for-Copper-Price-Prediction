
% 
% %% 预测0.0001到0.9999. 间隔0.005
% tau1 = 0.001:0.005:0.999;
% for i = 1:length(tau1)
%     PRE_LSTM(i,:)=QRLSTM(p_train, t_train,ps_output,p_test,T_test,tau1(i));
% end
load PRE_LSTM.mat

%% KDE
% load result.mat
%设置核函数分别为Gaussian，Uniform，Triangle和Epanechnikov
%调用ksdensity函数进行核密度检验
% [f_ks1,xi1]=ksdensity(score,'kernel','normal');
% [f_ks2,xi2]=ksdensity(score,'kernel','box');
% [f_ks3,xi3]=ksdensity(score,'kernel','triangle');
% [f_ks4,xi4]=ksdensity(score,'kernel','epanechnikov');
% 绘制几个时刻上的概率密度
% for i = 1:9
%     data = PRE_LSTM(:,i);
%     [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
%     subplot(3,3,i)
%     plot(xi1,f_ks1,'b','linewidth',1);
%     xlabel('Copper Price')
%     ylabel('Probability Density')
%     ylim=get(gca,'Ylim'); 
%     hold on
%     plot([T_test(:,i),T_test(:,i)],ylim,'r--','linewidth',1); 
%     % 绘制x=1的直线
% end

data_2 = PRE_LSTM(:,12);
    [f_ks1,xi1]=ksdensity(data_2,'kernel','epanechnikov');
    subplot(2,3,1)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 12th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,12),T_test(:,12)],ylim,'r--','linewidth',1); 

data_2 = PRE_LSTM(:,24);
    [f_ks1,xi1]=ksdensity(data_2,'kernel','epanechnikov');
    subplot(2,3,2)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 24th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,24),T_test(:,24)],ylim,'r--','linewidth',1); 

data_3 = PRE_LSTM(:,36);
    [f_ks1,xi1]=ksdensity(data_3,'kernel','epanechnikov');
    subplot(2,3,3)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 36th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,36),T_test(:,36)],ylim,'r--','linewidth',1); 

data_4 = PRE_LSTM(:,48);
    [f_ks1,xi1]=ksdensity(data_4,'kernel','epanechnikov');
    subplot(2,3,4)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 48th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,48),T_test(:,48)],ylim,'r--','linewidth',1); 

data_5 = PRE_LSTM(:,60);
    [f_ks1,xi1]=ksdensity(data_5,'kernel','epanechnikov');
    subplot(2,3,5)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 60th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,60),T_test(:,60)],ylim,'r--','linewidth',1); 

data_6 = PRE_LSTM(:,72);
    [f_ks1,xi1]=ksdensity(data_6,'kernel','epanechnikov');
    subplot(2,3,6)
    plot(xi1,f_ks1,'b','linewidth',1);
    xlabel('Copper Price')
    ylabel('Probability Density')
    title('The 72th moment')
    ylim=get(gca,'Ylim'); 
    hold on
    plot([T_test(:,72),T_test(:,72)],ylim,'r--','linewidth',1); 

