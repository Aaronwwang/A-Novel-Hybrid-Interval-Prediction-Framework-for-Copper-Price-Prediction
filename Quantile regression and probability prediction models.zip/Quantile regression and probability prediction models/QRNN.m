function [PRE]=QRNN(pn,tn,outputps,pn1,y,tau);
numFeatures = size(pn,1);% 特征维度=滑动窗长度
numResponses = 1;
FiltZise = 5;

%%%% RNN 结构设计
    layers = [...
        sequenceInputLayer(numFeatures)
        gruLayer(128,'Name','gru1','RecurrentWeightsInitializer','He','InputWeightsInitializer','He')
        lstmLayer(64,'Name','gru2','RecurrentWeightsInitializer','He','InputWeightsInitializer','He')
        dropoutLayer(0.5,'Name','drop2')
        lstmLayer(FiltZise,'OutputMode','sequence')
        gruLayer(FiltZise)
        dropoutLayer(0.25)
       fullyConnectedLayer(numResponses,'Name','fc')
        quanRegressionLayer('out',tau)];

%%%%% 网络参数设置
% if gpuDeviceCount>0
%     mydevice = 'gpu';
% else
%     mydevice = 'cpu';
% end

options = trainingOptions('adam', ...
        'MaxEpochs',300, ...
        'GradientThreshold',1, ...
        'InitialLearnRate',0.001, ...
        'LearnRateSchedule',"piecewise", ...
        'LearnRateDropPeriod',100, ...
        'LearnRateDropFactor',0.25, ...
        'MiniBatchSize',32,...
        'Verbose',false, ...
        'Shuffle','every-epoch',...
        'ExecutionEnvironment','cpu');
net = trainNetwork(pn,tn,layers,options);
YPred = predict(net,pn1,'MiniBatchSize',1);
PRE= mapminmax('reverse',YPred,outputps);
end