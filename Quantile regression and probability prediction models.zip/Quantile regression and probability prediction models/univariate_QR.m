clc;
clear;
load copper.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Y = copper;
n = 72;
T=length(Y);
step = 1;
l = 5;
tr=T-n-step-l+1;
for j=1:T-l-step+1
    input(j,:)=Y(j:j+l-1);
    output(j,:)=Y(j+l:j+l+step-1)';
end
output=output(:,step);
input_train=input(1:tr,:)';
input_test=input(tr+1:end,:)';
output_train=output(1:tr)';
output_test=copper(end-n+1:end);
%% 训练数据和预测数据归一化
[inputn,inputps]=mapminmax(input_train,0,1);
[outputn,outputps]=mapminmax(output_train,0,1);
inputn_test=mapminmax('apply',input_test,inputps);

n=1
picp=zeros(1,30);
AIS=zeros(1,30);
PICP=zeros(1,30);
pinaw=zeros(1,30);
quantileloss=zeros(1,30);
while n<30

%% 分位数预测
% QRLSTM
tau = 0.025
[PRE_LSTM]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau);
% hold on
% plot(PRE_LSTM,'r-')
% plot(output_test,'b')
% hold off
PICP(n) = sum(PRE_LSTM'<output_test)/length(output_test)*100;
quantileloss(n) = QR(output_test, PRE_LSTM', tau);  % 计算quantile loss

%% 区间预测
tau1 = [0.025, 0.975];
for i = 1:2
[PRE_LSTM(i,:)]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
end
hold on
plot(PRE_LSTM','r-')
plot(output_test,'b')
hold off
% 评价
alpha = 1-(tau1(2)-tau(1));
UB = PRE_LSTM(2,:)';
LB = PRE_LSTM(1,:)';
actual = output_test;
[picp(n), pinaw(n), AIS(n)] = Metric_interval(alpha,UB,LB,actual);

n=n+1
end
PICP=sum(PICP)/30
quantileloss=sum(quantileloss)/30
picp=sum(picp)/30
pinaw=sum(pinaw)/30
AIS=sum(AIS)/30

% %% 预测0.0001到0.9999. 间隔0.005
% tau1 = 0.001:0.005:0.999;
% for i = 1:length(tau1)
%     PRE_LSTM(i,:)=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
% end

%

