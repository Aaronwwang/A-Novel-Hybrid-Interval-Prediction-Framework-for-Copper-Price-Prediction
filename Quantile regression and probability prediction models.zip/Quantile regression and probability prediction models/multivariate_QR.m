clear;clc;
%%  导入数据
%%  导入数据
load common_train.mat
P_train = common_train(:,1:4)';  %commom_train的第1-20行存放到P_train中 P变量，T铜
T_train = common_train(:,end)';   %取最后一列  

load common_test.mat
P_test = common_test(:,1:4)';
T_test = common_test(:,end)';

% %金价
% n=0.8;%训练集占比
% load golddata2.mat
% gold_price=golddata2;
% train=gold_price(1:880*n,:);
% test=gold_price(880*n+1:879,:);
% 
% P_train = train(:,2:end)';  %xtrain的第1-20列存放到P_train中 P变量，T铜
% T_train = train(:,1)';   
% P_test = test(:,2:end)';
% T_test = test(:,1)';                  % 输入特征维度
% outdim = 1;                           % 最后一列为输出
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);
%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

%picp=0;
%while picp<80

%% 区间预测
tau1 = [0.05,0.95];
for i = 1:2
[copper_NN05(i,:)]=QRbiGRU(p_train, t_train,ps_output,p_test,T_test,tau1(i));
% PICP(n) = sum(PRE_QR>T_test)/length(T_test)*100;%PICP半区间指标
%quantileloss = QR(T_test, copper_LSTM05(i,:), tau1(i));
end
%画图
% hold on
% plot(gold_LSTM','r-')
% plot(T_test,'b')
% hold off
%评价指标
alpha = 1-(tau1(2)-tau1(1));
UB = copper_NN05(2,:);
LB = copper_NN05(1,:);
actual = T_test;
[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)

%end

%save('data.mat', 'data')


% 
% %核密度估计
% %% 预测0.0001到0.9999. 间隔0.005
% tau1 = 0.001:0.01:0.999;
% for i = 1:length(tau1)
%     tau1(i)
%     kernel_QRGRU(i,:)=QRGRU(p_train, t_train,ps_output,p_test,T_test,tau1(i));
% end
% 
% % KDE
% load kernel_QRLSTM.mat
% %设置核函数分别为Gaussian，Uniform，Triangle和Epanechnikov
% %调用ksdensity函数进行核密度检验
% % [f_ks1,xi1]=ksdensity(score,'kernel','normal');
% % [f_ks2,xi2]=ksdensity(score,'kernel','box');
% % [f_ks3,xi3]=ksdensity(score,'kernel','triangle');
% %f_ks4,xi4]=ksdensity(kernel_QRLSTM,'kernel','epanechnikov');
% %绘制几个时刻上的概率密度
% n = linspace(1, 73, 9)
% for i = 1:9
%     data = kernel_QRLSTM(:,n(i));
%     [f_ks1,xi1]=ksdensity(data,'kernel','epanechnikov');
%     subplot(3,3,i)
%     plot(xi1,f_ks1,'b','linewidth',1);
%     xlabel('copper price')
%     ylabel('条件概率密度')
%     ylim=get(gca,'Ylim'); 
%     hold on
%     plot([T_test(:,n(i)),T_test(:,n(i))],ylim,'r--','linewidth',1); % 绘制x=1的直线
% end
% % 

