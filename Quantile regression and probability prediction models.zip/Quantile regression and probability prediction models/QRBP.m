function [PRE]=QRBP(pn,tn,outputps,pn1,y,tau);
% pn代表inputn  tn代表outputn pn1是inputn_test,y是真实值。

%numResponses = 1;
featureDimension = size(pn,1);
%numHiddenUnits = 5;
% 创建神经网络
hiddenSize = 9; % 隐藏层节点数
layers = [ 
    sequenceInputLayer(featureDimension)
    %sigmoidLayer
    fullyConnectedLayer(hiddenSize) 
    sigmoidLayer  
    fullyConnectedLayer(1)  
    sigmoidLayer
    %regressionLayer
    quanRegressionLayer('out',tau)];

 options = trainingOptions('adam', ...      % Adam梯度下降算法
        'MaxEpochs',1300, ...                  % 最大训练次数 600
       'InitialLearnRate', 0.01, ...          % 初始学习率为 0.01
      'LearnRateSchedule', 'piecewise', ...  % 学习率下降
        'LearnRateDropFactor', 0.2, ...        % 学习率下降因子 0.2
        'LearnRateDropPeriod', 800, ...        % 经过 400 次训练后 学习率为 0.01 * 0.2
        'Shuffle', 'every-epoch', ...          % 训练打乱数据集
        'ValidationPatience', Inf, ...         % 关闭验证
        'Verbose',false ...
        );

% options =  trainingOptions('sgdm', ...
%     'MaxEpochs', 1000, ...
%     'InitialLearnRate', 0.1, ...
%     'MiniBatchSize', 1, ...
%     'Plots', 'training-progress');

net = trainNetwork(pn,tn,layers,options);
YPred = predict(net,pn1,'MiniBatchSize',1);
PRE= mapminmax('reverse',YPred,outputps);
end

