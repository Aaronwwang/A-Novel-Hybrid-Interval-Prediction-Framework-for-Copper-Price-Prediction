clear;clc
% load S1
% X0 = S1./max(S1);
load golddata.mat
X0 = golddata;%(4:end,1:10)./max(AllData(4:end,1:10));
% X0 = min(AllData(4:end,1:10))./AllData(4:end,1:10);
% X0 = (AllData(4:end,1:10)-mean(AllData(4:end,1:10)))./std(AllData(4:end,1:10));
% X0 = AllData(4:end,1:10);
% data = AllData(4:end,1:10);
% X0 = data./(data(1,:));


y = X0(:,1);
x = X0(:,2:end);
% x=[x1,x2,x3,x4,x5,x6,x7];

[b,fitinfo] = lasso(x,y,'CV',10,'Alpha',1); % 参数初始化
axTrace = lassoPlot(b,fitinfo); %交叉验证训练轨迹
axCV = lassoPlot(b,fitinfo,'PlotType','CV');
lam = fitinfo.IndexMinMSE;  % 最小MSE对应lambda
mat = b(:,lam);             % 最优lambda对应的稀疏系数
[row, ] = find(b(:,lam)~=0);% 非零系数对应的行
Xla = x(:, row');           % 筛选稀疏变量