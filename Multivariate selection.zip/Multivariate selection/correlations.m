clear;clc;
format long 
load all_gold_data.mat
X0=golddata
% 灰色关联度检验
% X0 = data./max(data);
% X0 = min(data)./data;
%X0 = (data-mean(data))./std(data);

C1 = corr(X0,'Type','Pearson');
C2 = corr(X0,'Type','Kendall');
C3 = corr(X0,'Type','Spearman');