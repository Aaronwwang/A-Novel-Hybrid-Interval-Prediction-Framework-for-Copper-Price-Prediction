   clear;clc;
%%  导入数据
load common_train.mat
P_train = common_train(:,1:4)';  %commom_train的第1-20行存放到P_train中 P变量，T铜
T_train = common_train(:,end)';   %取最后一列  

load common_test.mat
P_test = common_test(:,1:4)';
T_test = common_test(:,end)';

P_validation = common_train(216:288,1:4)';  %common_train的第216-288行存放到P_validation中 
T_validation = common_train(216:288,end)';

f_=size(P_train, 1);                  % 输入特征维度
outdim = 1;    
%%  划分训练集和测试集
M = size(P_train, 2);
N = size(P_test, 2);

%%  数据归一化
[p_train, ps_input] = mapminmax(P_train, 0, 1);
p_test = mapminmax('apply', P_test, ps_input);

[p_validation, ps_P_validation] = mapminmax(P_validation, 0, 1);
[t_validation, ps_T_validation] = mapminmax(T_validation, 0, 1);

[t_train, ps_output] = mapminmax(T_train, 0, 1);
t_test = mapminmax('apply', T_test, ps_output);

% load biLSTM_test_05.mat
% load biLSTM_test_95.mat
% load biLSTM_test_025.mat
% load biLSTM_test_975.mat
% load GRU_test_05.mat
% load GRU_test_95.mat
% load GRU_test_025.mat
% load GRU_test_975.mat
% biLSTM_test1=[biLSTM_test_05;biLSTM_test_95];
% biLSTM_test2=[biLSTM_test_025;biLSTM_test_975];
load copper_LSTM025.mat

picp = 0;
while picp < 92 || picp > 98

tau1 = [0.025 0.975];
for i = 1:length(tau1)
    tau1(i)
    [PRE_QR_validation] = QRLSTM(p_train,t_train,ps_T_validation,p_validation,t_validation,tau1(i));

    actual_1 = T_validation;%输入对应的真实值
    actual_2 = T_test;%测试集

    y1 = PRE_QR_validation;%输入拟合值

    y2 = copper_LSTM025(i,:);%输入预测值

    [Best_universe,optimized_PRE_QR_train,copper_opt_LSTM025(i,:)] = ...
      IMOMVO(1,y1,y2,actual_1,tau1(i));%优化
end

alpha = 1-(tau1(2)-tau1(1));
UB = copper_opt_LSTM025(2,:);
LB = copper_opt_LSTM025(1,:);
actual = T_test;
[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual)

end
%save('copper_opt_LSTM025.mat', 'copper_opt_LSTM025')

% picp_test=0;
% pinaw_test=0;
% while picp_test<90 
% 
% % 分位数预测
% tau = 0.95
% 
% %预测拟合值
% [PRE_QR_validation]=QRbiGRU(p_train,t_train,ps_T_validation,p_validation,t_validation,tau);
% if tau>0.5
% PICP_validation = sum(PRE_QR_validation>T_validation)/length(T_validation)*100
% else
%     PICP_validation = sum(PRE_QR_validation<T_validation)/length(T_validation)*100
% end
% hold on 
% plot(PRE_QR_validation,'r')
% plot(T_validation,'b')
% hold off
% %预测测试值
% [PRE_QR_test]=QRLSTM(p_train, t_train,ps_output,p_test,t_test,tau);
% PICP_test = sum(PRE_QR_test>T_test)/length(T_test)*100

% %MOMVO优化
% load GRU_test_95.mat
% dim=1;%输入个数
% actual_1=T_validation;%输入对应的真实值
% actual_2=T_test;%测试集
% y1=PRE_QR_validation;%输入拟合值
% 
% y2=GRU_test_95;%输入预测值
% 
% [Best_universe,optimized_PRE_QR_train,optimized_GRU_test95]=...
%       IMOMVO(dim,y1,y2,actual_1,tau);%优化
% 
% %计算优化后拟合值的半区间指标
% if tau>0.5
% pinaw_train = 1/range(actual_1) * sum( (optimized_PRE_QR_train-actual_1 )./ actual_1) %pinaw上界
% picp_train = sum(optimized_PRE_QR_train>actual_1)/length(actual_1)*100 %picp上界 
% else
% pinaw_train = 1/range(actual_1) * sum( (actual_1 -optimized_PRE_QR_train )./ actual_1)   %pinaw下界
% picp_train = sum(optimized_PRE_QR_train<actual_1)/length(actual_1)*100   %picp下界
% end
% 
% %计算优化后预测值的半区间指标
% if tau>0.5
% pinaw_test = 1/range(actual_2) * sum( (optimized_GRU_test95-actual_2 )./ actual_2) %pinaw上界
% picp_test = sum(optimized_GRU_test95>actual_2)/length(actual_2)*100 %picp上界 
% else
% pinaw_test = 1/range(actual_2) * sum( (actual_2 -optimized_GRU_test95 )./ actual_2)   %pinaw下界
% picp_test = sum(optimized_GRU_test95<actual_2)/length(actual_2)*100   %picp下界
% end
%  
% end

% %% 预测0.0001到0.9999. 间隔0.1
% load gold_LSTM.mat
% tau1 = 0.005:0.995;
% for i = 1:length(tau1)
%     tau1(i)
%     [PRE_QR_validation]=QRLSTM(p_train,t_train,ps_T_validation,p_validation,t_validation,tau1(i));
%     actual_1=T_validation;%输入对应的真实值
%     actual_2=T_test;%测试集
%     y1=PRE_QR_validation;%输入拟合值gold_LSTM.mat
%     y2=gold_LSTM(i,:);%输入预测值
%     [Best_universe,optimized_PRE_QR_train,gold_LSTM(i,:)]=...
%       IMOMVO(dim,y1,y2,actual_1,tau1(i));%优化
% end