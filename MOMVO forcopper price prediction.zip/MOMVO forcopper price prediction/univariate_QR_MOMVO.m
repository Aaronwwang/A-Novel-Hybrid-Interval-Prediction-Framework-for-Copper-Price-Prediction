clc;
clear;
load copper.mat
Y = copper;
n = 72;
T=length(Y);
step = 1;
l = 5;
tr=T-n-step-l+1;
for j=1:T-l-step+1
    input(j,:)=Y(j:j+l-1);
    output(j,:)=Y(j+l:j+l+step-1)';
end
output=output(:,step);
input_train=input(1:tr,:)';
input_test=input(tr+1:end,:)';
output_train=output(1:tr)';
output_test=copper(end-n+1:end);
%% 训练数据和预测数据归一化
[inputn,inputps]=mapminmax(input_train,0,1);
[outputn,outputps]=mapminmax(output_train,0,1);
inputn_test=mapminmax('apply',input_test,inputps);

% %% 分位数预测
% % QRLSTM
%tau = 0.025
% [PRE_LSTM]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau);
% PICP = sum(PRE_LSTM'<output_test)/length(output_test)*100;
% quantileloss = QR(output_test, PRE_LSTM', tau);  % 计算quantile loss

%% 区间预测
tau=0.025;
tau1 = [0.025, 0.975];
for i = 1:2
[PRE_LSTM(i,:)]=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
end
% hold on
% plot(PRE_LSTM','r-')
% plot(output_test,'b')
% hold off
% 评价
alpha = 1-(tau1(2)-tau(1));
UB = PRE_LSTM(2,:)';
LB = PRE_LSTM(1,:)';
actual = output_test;
[picp, pinaw, AIS] = Metric_interval(alpha,UB,LB,actual);

%MOMVO
dim=1;
y1=LB; %UB,LB
%actual= output_test;
[train,uniL25,MAPE,MAE,RMSE,SDE]=IMOMVO(dim,y1,actual,tau);
%pinaw_U = 1/range(actual) * sum( (uniU25-actual )./ actual) %pinaw上界
%picp_U = sum(uniU25>actual)/length(actual)*100 %picp上界 
pinaw_L = 1/range(actual) * sum( (actual -uniL25 )./ actual)   %pinaw下界
picp_L = sum(uniL25<actual)/length(actual)*100   %picp下界

disp(['SDE:' num2str(SDE) ...
     'RMSE:' num2str(RMSE)...
     'MAE:' num2str(MAE)...
     'MAPE:' num2str(MAPE) '%'])
% %% 预测0.0001到0.9999. 间隔0.005
% tau1 = 0.001:0.005:0.999;
% for i = 1:length(tau1)
%     PRE_LSTM(i,:)=QRLSTM(inputn,outputn,outputps,inputn_test,output_test,tau1(i));
% end

%

