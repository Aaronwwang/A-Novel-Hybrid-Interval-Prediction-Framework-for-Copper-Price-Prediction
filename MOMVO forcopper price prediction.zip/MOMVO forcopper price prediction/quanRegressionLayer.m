


classdef quanRegressionLayer < nnet.layer.RegressionLayer
    properties
        tau
    end
    methods
        function layer = quanRegressionLayer(name,tau)
            layer.tau = tau;
            layer.Name = name;
            layer.Description = 'quantile error';
        end
        
        function loss = forwardLoss(layer, Y, T)
  
            R = size(Y,1);
            quantileError = sum(max(layer.tau*(T-Y),(1-layer.tau)*(Y-T)))/R;  
            
            N = size(Y,3);
            loss = sum(quantileError)/N;
        end
        function dLdY = backwardLoss(layer,Y,T)
           
            dLdY =  single(-layer.tau*(T-Y>= 0) + (1-layer.tau) * (Y-T>=0));
                    
        end
        
        
    end
end


