function [PRE]=QRbiGRU(pn,tn,outputps,pn1,y,tau);
numResponses = 1;
featureDimension = size(pn,1); 
numhidden_units1=50;
numhidden_units2=300;
numhidden_units3=100;
%% gru
layers = [ ...
    sequenceInputLayer(featureDimension)                 %输入层设置
    gruLayer(numhidden_units1,'name','hidden1')  %隐藏层学习层设置(cell层）
    dropoutLayer(0.2,'name','dropout_1')          %隐藏层权重丢失率，防止过拟合
    gruLayer(numhidden_units2,'Outputmode','sequence','name','hidden2')%隐藏层
    dropoutLayer(0.3,'name','dropout_2')          %隐藏层权重丢失率，防止过拟合
    gruLayer(numhidden_units3,'name','hidden3')  %隐藏层
    dropoutLayer(0.2,'name','dropout_3')          %隐藏层权重丢失率，防止过拟合
    fullyConnectedLayer(numResponses)               %全连接层设置（影响输出维度）（cell层出来的输出层） 
    quanRegressionLayer('out',tau)];               %回归层（因为预测值为连续值，所以为回归层） 
%% trainoption(gru)
% options = trainingOptions('adam', ...      %优化算法
%     'MaxEpochs',500, ...                %遍历样本最大循环数
%     'GradientThreshold',1,...           %梯度阈值
%     'ExecutionEnvironment','cpu',...    %运算环境
%     'InitialLearnRate',0.005, ...       %初始学习率
%     'LearnRateSchedule','piecewise', ...% 学习率计划
%     'LearnRateDropPeriod',160, ...      %epoch后学习率更新
%     'LearnRateDropFactor',0.8, ...      %学习率衰减速度
%     'Verbose',0 ...                    %命令控制台是否打印训练过程     %打印训练进度
%     );
MaxEpochs=700;%最大迭代次数
InitialLearnRate=0.005;%初始学习率
options = trainingOptions('adam', ...
'MaxEpochs',MaxEpochs,...%30用于训练的最大轮次数，迭代是梯度下降算法中使用小批处理来最小化损失函数的一个步骤。一个轮次是训练算法在整个训练集上的一次全部遍历。
 'MiniBatchSize',100, ... %128小批量大小，用于每个训练迭代的小批处理的大小，小批处理是用于评估损失函数梯度和更新权重的训练集的子集。
'GradientThreshold',1, ...%梯度下降阈值
'InitialLearnRate',InitialLearnRate, ...%全局学习率。默认率是0.01，但是如果网络训练不收敛，你可能希望选择一个更小的值。默认情况下，trainNetwork在整个训练过程中都会使用这个值，除非选择在每个特定的时间段内通过乘以一个因子来更改这个值。而不是使用一个小的固定学习速率在整个训练, 在训练开始时选择较大的学习率，并在优化过程中逐步降低学习率，可以帮助缩短训练时间，同时随着训练的进行，可以使更小的步骤达到最优值，从而在训练结束时进行更精细的搜索。
'LearnRateSchedule','piecewise', ...%在训练期间降低学习率的选项，默认学习率不变。'piecewise’表示在学习过程中降低学习率
 'LearnRateDropPeriod',100, ...% 10降低学习率的轮次数量，每次通过指定数量的epoch时，将全局学习率与学习率降低因子相乘
'LearnRateDropFactor',0.25, ...%学习下降因子
'ValidationData',{pn,tn}, ...% ValidationData用于验证网络性能的数据，即验证集
 'ValidationFrequency',1, ...%以迭代次数表示的网络验证频率，“ValidationFrequency”值是验证度量值之间的迭代次数。
'Verbose',0);%1指示符，用于在命令窗口中显示训练进度信息，显示的信息包括轮次数、迭代数、时间、小批量的损失、小批量的准确性和基本学习率。训练一个回归网络时，显示的是均方根误差(RMSE)，而不是精度。如果在训练期间验证网络。
net = trainNetwork(pn,tn,layers,options);
YPred = predict(net,pn1,'MiniBatchSize',1);
PRE= mapminmax('reverse',YPred,outputps);
end