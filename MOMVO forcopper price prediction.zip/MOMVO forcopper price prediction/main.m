%______________________________________________________________________________________
%  Multi-Objective Multi-Verse Optimization (MOMVO) algorithm source codes version 1.0
%
%  Developed in MATLAB R2016a
%
%  Author and programmer: Seyedali Mirjalili
%
%         e-Mail: ali.mirjalili@gmail.com
%                 seyedali.mirjalili@griffithuni.edu.au
%
%       Homepage: http://www.alimirjalili.com
%
%   Main paper:
%   S. Mirjalili, P. Jangir, S. Z. Mirjalili, S. Saremi, and I. N. Trivedi
%   Optimization of problems with multiple objectives using the multi-verse optimization algorithm, 
%   Knowledge-based Systems, 2017, DOI: http://dx.doi.org/10.1016/j.knosys.2017.07.018
%______________________________________________________________________________________

clear all;
close all;
clc;
format long g

% Initial parameters of the MODA algorithm
max_iter=100;
N=100;
ArchiveMaxSize=100;
obj_no=2;
Archive_F1=load('weldedbeam.txt');
%-------------------------- MOMVO -----------------------------------------
for i=1:5   % Numbver of independent runs
    
[Best_universe_score,Best_universe_pos,Archive_F]=MOMVO(max_iter,N,ArchiveMaxSize);
    
%% using the matlab codes for calculating metric values
hv = hypeIndicatorExact8(Archive_F, ones(1, obj_no), obj_no); 
gd = GD_matlab(Archive_F, Archive_F1);
epsilonNew = epsilon_matlab(Archive_F, Archive_F1);
spread = Spread_matlab(Archive_F, Archive_F1);
generalizedspread = GeneralizedSpread_matlab(Archive_F, Archive_F1);
igd = IGD_matlab(Archive_F, Archive_F1);
disp(['hv = ' num2str(hv)  '  GD = ' num2str(gd)  ' epsilon = ' num2str(epsilonNew)  '  Spread = ' num2str(spread)  '  GSpread = ' num2str(generalizedspread)  '  IGD = ' num2str(igd) ]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
GD=Generational_distance(Archive_F,Archive_F1);
S=metric_of_spacing(Archive_F);
DELTA= Diversity_metric_delta(Archive_F,Archive_F1);
MS=metric_of_maximum_spread(Archive_F,Archive_F1);
disp(['GD = ' num2str(GD)  '  S = ' num2str(S)  ' DELTA = ' num2str(DELTA)  '   MS = ' num2str(MS)   ]);   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
plot(Archive_F1(:,1),Archive_F1(:,2),'Color','b','LineWidth',4);
 hold on
plot(Archive_F(:,1),Archive_F(:,2),'ro','LineWidth',2,...
        'MarkerEdgeColor','r',...
        'MarkerFaceColor','r',...
        'MarkerSize',6);
legend('True PF','Obtained PF');
title('MOMVO FOR Welded beam design PROBLEM');
xlabel('obj_1');
ylabel('obj_2');

    hold off
    
    fprintf('%d %20.15f %20.15f %20.15f %20.15f\n',i,GD,S,DELTA,MS);
    fprintf('%d %20.15f %20.15f %20.15f %20.15f %20.15f %20.15f\n',i,hv,gd,epsilonNew,spread,generalizedspread,igd);
    GGD(i)=GD;
    SS(i)=S;
    DELTAA(i)=DELTA;
    MSS(i)=MS;
    
    
hvd(i)=hv;
gdd(i)=gd;
epsilonNewd(i)=epsilonNew;
spreadd(i)=spread;
generalizedspreadd(i)=generalizedspread;
igdd(i)=igd;

    
end

Min_Generational_distance=min(GGD)
Average_Generational_distance=mean(GGD)
Max_Generational_distance=max(GGD)
SD_Generational_distance=std(GGD)

Min_metric_of_spacing=min(SS)
Average_metric_of_spacing=mean(SS)
Max_metric_of_spacing=max(SS)
SD_metric_of_spacing=std(SS)

Min_Diversity_metric_delta=min(DELTAA)
Average_Diversity_metric_delta=mean(DELTAA)
Max_Diversity_metric_delta=max(DELTAA)
SD_Diversity_metric_delta=std(DELTAA)

Min_metric_of_maximum_spread=min(MSS)
Average_metric_of_maximum_spread=mean(MSS)
Max_metric_of_maximum_spread=max(MSS)
SD_metric_of_maximum_spread=std(MSS)

Min_hypeIndicatorExact8=min(hvd)
Average_hypeIndicatorExact8=mean(hvd)
Max_hypeIndicatorExact8=max(hvd)
SD_hypeIndicatorExact8=std(hvd)

Min_Generational_distance1=min(gdd)
Average_Generational_distance1=mean(gdd)
Max_Generational_distance1=max(gdd)
SD_Generational_distance1=std(gdd)

Min_epsilon=min(epsilonNewd)
Average_epsilon=mean(epsilonNewd)
Max_epsilon=max(epsilonNewd)
SD_epsilon=std(epsilonNewd)


Min_spread=min(spreadd)
Average_spread=mean(spreadd)
Max_spread=max(spreadd)
SD_spread=std(spreadd)


Min_generalizedspread=min(generalizedspreadd)
Average_generalizedspread=mean(generalizedspreadd)
Max_generalizedspread=max(generalizedspreadd)
SD_generalizedspread=std(generalizedspreadd)


Min_IGD=min(igdd)
Average_IGD=mean(igdd)
Max_IGD=max(igdd)
SD_IGD=std(igdd)

Best_universe_score
Best_universe_pos